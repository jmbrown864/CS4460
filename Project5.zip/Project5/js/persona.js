function Persona(name, img) {
    this.name = name;
    this.img = img;
}

Persona.prototype.init = function(g, x, y) {

}

Persona.prototype.update = function(g, x, y) {

}